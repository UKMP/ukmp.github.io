$(function() {
  $(".drag-me").draggable();
});
